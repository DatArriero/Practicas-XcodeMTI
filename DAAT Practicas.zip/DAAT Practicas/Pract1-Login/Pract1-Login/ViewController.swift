//
//  ViewController.swift
//  Pract1-Login
//
//  Created by MTI  on 28/01/19.
//  Copyright © 2019 MTI . All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var txtUsuario: UITextField!
    
    @IBOutlet weak var txtContra: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        //Inicializar evento de touch para ocuiltar teclado
        let tap = UITapGestureRecognizer(target: self, action: #selector(ocultarTeclado))
        view.addGestureRecognizer(tap)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func loginPresionado(_ sender: UIButton) {
        
        //CONSTANTES para LOGIN
        let usuario = "Daniel Arriero"
        let contra = "160306"
        
        if (usuario == txtUsuario.text && contra == txtContra.text) {
            print("Generar alerta de Bienvenida")
            
            //generar alerta
            let alerta = UIAlertController(title:"Bienvenido", message:"Crfedenciales Correctas", preferredStyle: .alert)
            //Agregar acciones a alerta
            alerta.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            //Mostrar la Alerta
            self.present(alerta, animated: true, completion: nil)
            
        } else{
            print("Generar alerta de Error")
            
            //generar alerta
            let alerta = UIAlertController(title:"Bienvenido", message:"Crfedenciales Correctas", preferredStyle: .alert)
            //Agregar acciones a alerta
            alerta.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            //Mostrar la Alerta
            self.present(alerta, animated: true, completion: nil)
        }
        
    }
    
    //Metodo para Ocultar el TEclado
    @objc
    func ocultarTeclado() {
        view.endEditing(true)
    }
    
}

