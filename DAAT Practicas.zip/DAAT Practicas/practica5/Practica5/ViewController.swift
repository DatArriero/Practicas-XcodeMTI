//
//  ViewController.swift
//  Practica5
//
//  Created by MTI on 04/03/19.
//  Copyright © 2019 MTI. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet weak var movies: UITableView!
    
    //Repositorio de peliculas
    var movieList = [movieModel]()
    var selectedMovie: movieModel?
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        movies.dataSource = self
        movies.delegate = self
        
        getMovies()
        movies.reloadData()
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return movieList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "movie") as! MovieTableViewCell
        cell.imageMovie.image = movieList[indexPath.row].movieImage
        cell.lblDuracion.text = movieList[indexPath.row].duracion
        cell.lblGenero.text = movieList[indexPath.row].genero
        cell.lblTitulo.text = movieList[indexPath.row].movieTitle
        return cell
    }
    //Request de peliculas
    func getMovies(){
        movieList.append(movieModel(movieTitle: "Como Entrenar a tu Dragon", sinopsis: "Hipo, un vikingo adolescente, comienza las clases de entrenamiento con dragones y ve por fin una oportunidad para demostrar que es capaz de convertirse en guerrero cuando hace amistad con un dragón herido.", genero: "Fantasía y aventura", duracion: "1:48", movieImage: UIImage(named: "Dragon1")!))
        
        movieList.append(movieModel(movieTitle: "Como Entrenar a tu Dragon 2", sinopsis: "Después de descubrir una cueva secreta llena de dragones salvajes y a su misterioso benefactor, Hipo y Chimuelo se encuentran a sí mismos en el centro de una batalla para proteger la paz de Berk.", genero: "Fantasía y aventura", duracion: "1:45", movieImage: UIImage(named: "Dragon2")!))
        
        movieList.append(movieModel(movieTitle: "Como entrenar a tu Dragon 3", sinopsis: "Hipo descubre que Chimuelo no es el único Furia Nocturna y debe buscar el Mundo Oculto, una utopía secreta para descubrir finalmente sus destinos como dragón y jinete.", genero: "Fantasía y aventura", duracion: "1:44", movieImage: UIImage(named: "Dragon3")!))
        
        movieList.append(movieModel(movieTitle: "Infinty War", sinopsis: "Los superhéroes se alían para vencer al poderoso Thanos, el peor enemigo al que se han enfrentado. Si Thanos logra reunir las seis gemas del infinito: poder, tiempo, alma, realidad, mente y espacio, nadie podrá detenerlo.", genero: "Fantasía y aventura", duracion: "2:40", movieImage: UIImage(named: "Infinitywar")!))
        
        movieList.append(movieModel(movieTitle: "Infinity War End Game", sinopsis: "Los Vengadores restantes deben encontrar una manera de recuperar a sus aliados para un enfrentamiento épico con Thanos, el malvado que diezmó el planeta y el universo. ", genero: "Fantasía y aventura", duracion: "3:15", movieImage: UIImage(named: "Endgame")!))
    
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        selectedMovie = movieList[indexPath.row]
        performSegue(withIdentifier: "detalle", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "detalle" {
            let vc = segue.destination as! detaileViewController
            vc.movie = selectedMovie
        }
    }
}

