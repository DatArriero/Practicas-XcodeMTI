//
//  ViewController.swift
//  P3-TableView
//
//  Created by administrador on 2/18/19.
//  Copyright © 2019 administrador. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if(section == 0){
            return America.count;
        }
            return Europa.count;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celda1")
        if(indexPath.section == 0) {
            cell?.textLabel?.text = America[indexPath.row]
        } else {
            cell?.textLabel?.text = Europa[indexPath.row]
        }
        return cell!
    }
    func sectionIndexTitles(for tableView: UITableView) -> [String]? {
        return ["America", "Europa", "CapiAmerica", "CapiEuropa"]
    }
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if(section == 0) {
            return "America"
        }
            return "Europa"
    }
    
    @IBOutlet weak var tableView: UITableView!
    
    //Fuente de Informacion
    let America = ["Mexico", "Canada", "Estados Unidos", "Cuba", "Colombia"]
    let Europa = ["Francia", "Alemania", " Portugal ", "Inglaterra", "Italia", "Africa", "Japon"]
    let CapiAmerica = ["CDMX", "Ottawa", "Washintong", "La Habana", "Lima", "Santiago", "Bogota"]
    let CapiEuropa = ["Paris", "Amsterdan", "Portugal", "Inglaterra", "Roma", "Africa", "Tokio"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        //asignar Protocolos
        tableView.dataSource = self
        tableView.delegate = self
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning();
    }
    
    //cuantas segciones tendra la tabla
    func numberOfSections(in tableView: UITableView) -> Int {
        return 4;
    }
}
