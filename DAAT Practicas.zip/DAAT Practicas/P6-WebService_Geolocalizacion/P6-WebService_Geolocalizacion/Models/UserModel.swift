//
//  UserModel.swift
//  P6-WebService_Geolocalizacion
//
//  Created by MTI on 11/03/19.
//  Copyright © 2019 MTI. All rights reserved.
//

import Foundation

class UserModel {
    //atributos
    var id: Int = -1
    var name: String = ""
    var username: String = ""
    var city: String = ""
    var lat: Double = 0
    var lng: Double = 0
    //constructor
    
    init(name: String, city: String){
        self.name = name
        self.city = city
    }
    // ..... mas Constructores
}
