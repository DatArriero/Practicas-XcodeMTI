//
//  P6_WebService_GeolocalizacionTests.swift
//  P6-WebService_GeolocalizacionTests
//
//  Created by MTI on 11/03/19.
//  Copyright © 2019 MTI. All rights reserved.
//

import XCTest
@testable import P6_WebService_Geolocalizacion

class P6_WebService_GeolocalizacionTests: XCTestCase {

    override func setUp() {
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }

    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func testExample() {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }

    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }

}
