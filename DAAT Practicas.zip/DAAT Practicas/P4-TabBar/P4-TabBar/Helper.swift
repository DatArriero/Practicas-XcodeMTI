//
//  Helper.swift
//  P4-TabBar
//
//  Created by MTI on 25/02/19.
//  Copyright © 2019 MTI. All rights reserved.
//

import Foundation

class Helper {
    
    static let shared = Helper()
    
    //tareas
    var task = [TaskModel]()
    private init(){
        
    }
}
