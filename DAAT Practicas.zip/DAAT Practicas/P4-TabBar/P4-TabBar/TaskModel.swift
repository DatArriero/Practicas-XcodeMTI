//
//  File.swift
//  P4-TabBar
//
//  Created by MTI on 25/02/19.
//  Copyright © 2019 MTI. All rights reserved.
//

import Foundation

class TaskModel{
    var name: String
    var dueDate: Date
    
    init(name: String, dueDate: Date){
        self.name = name
        self.dueDate = dueDate
    }
}
