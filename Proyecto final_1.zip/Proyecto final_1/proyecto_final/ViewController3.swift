//
//  ViewController3.swift
//  proyecto_final
//
//  Created by Villanueva on 03/12/18.
//  Copyright © 2018 All rights reserved.
//

import UIKit

var Peliculas:[String] = []
var Precios:[String] = []
var Duracion:[String] = []
var imag:[UIImage] = []

class ViewController3: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet weak var tableview: UITableView!
    
    
    
    let inicia_Peliculas = ["Derdevel", "Punisher", "Grimm", "Simpson"]
    let inicia_Precios = ["$280.00", "$325.00", "$525.00", "$200.00"]
    let inicia_Duracion = ["115 Minutos", "40 Minutos", "80 Minutos","120 Minutos"]
    let inicia_imag = [UIImage(named:"derde.jpg"),UIImage(named:"punisher.jpg"),UIImage(named:"grimm.jpg"),UIImage(named:"simpson.jpg")]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        tableview.dataSource = self
        tableview.delegate = self
        
        tableview.reloadData()
        
        let contador = Peliculas.count
        if(contador == 0){
            inicia_Peliculas.forEach { pelicula in
                Peliculas.append(pelicula)
            }
            inicia_Precios.forEach{ precio in
                Precios.append(precio)
            }
            inicia_Duracion.forEach{ durac in
                Duracion.append(durac)
            }
            inicia_imag.forEach{ imaage in
                imag.append(imaage!)
            }
        }
        let tap = UITapGestureRecognizer(target: self,action: #selector(hideKeyboard))
        view.addGestureRecognizer(tap)
        // Do any additional setup after loading the view, typically from a nib.
    }
    @objc func hideKeyboard()
    {
        view.endEditing(true)
    }
    
    @IBAction func recargar(_ sender: Any) {
        tableview.reloadData()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Peliculas.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let celda = tableView.dequeueReusableCell(withIdentifier: "celda") as! rest
        //7.-Después de construir la celda, se coloca la información correspondiente a la fila que se está mostrando
        celda.img.image = imag[indexPath.row]
        celda.pelicula.text = Peliculas[indexPath.row]
        celda.duracion.text = Duracion[indexPath.row]
        celda.precio.text = Precios[indexPath.row]
        return celda
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let alert = UIAlertController(title: "¿Usted desea comer \(Peliculas[indexPath.row])?", message: "", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
}

class rest: UITableViewCell{
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var pelicula: UILabel!
    
    @IBOutlet weak var duracion: UILabel!
    @IBOutlet weak var precio: UILabel!
}
