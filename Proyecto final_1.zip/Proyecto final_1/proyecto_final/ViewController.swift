//
//  ViewController.swift
//  proyecto_final
//
//  Created by Villanueva on 03/12/18.
//  Copyright © 2018 All rights reserved.
//

import UIKit
var users:[Users] = []
var numero_usuario = 0
class ViewController: UIViewController {
    @IBOutlet weak var usuario: UITextField!
    
    @IBOutlet weak var contraseña: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        let tap = UITapGestureRecognizer(target: self,action: #selector(hideKeyboard))
        view.addGestureRecognizer(tap)
        // Do any additional setup after loading the view, typically from a nib.
    }
    @objc func hideKeyboard()
    {
        view.endEditing(true)
    }
    
    @IBAction func ir_a_registro(_ sender: Any) {
         self.performSegue(withIdentifier: "ir_registro", sender: self)
    }
    
    @IBAction func validar_ingreso(_ sender: Any) {
        
        for a in users{
            if (a.usuario == usuario.text){
                if(a.contra == contraseña.text){
                    let alert=UIAlertController(title: a.usuario, message: "Se ha identificado como " + a.nombre, preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "Cerrar", style: .default, handler: {(action) in self.performSegue(withIdentifier: "ir_tab", sender: self)}))
                    present(alert, animated: true, completion: nil)
                }
                else
                {
                  numero_usuario = numero_usuario + 1
                }
                
            }
            else{
                numero_usuario = numero_usuario + 1
            }
            
        }
        
        if(usuario.text?.isEmpty)!{
            let alert=UIAlertController(title: "Error", message: "Ingrese usuario", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alert, animated: true, completion: nil)
        }
            
        else if (contraseña.text?.isEmpty)!{
            let alert=UIAlertController(title: "Error", message: "Ingrese contraseña", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alert, animated: true, completion: nil)
        }
        
        else{
            let alerta=UIAlertController(title: "Error", message: "Usuario no encontrado", preferredStyle: UIAlertController.Style.alert)
            alerta.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alerta, animated: true, completion: nil)
        }
    }
    

}

class Users{
    
    var usuario = String()
    var contra = String()
    var nombre = String()

    
    init(usuario: String, contra: String,nombre: String) {
        self.usuario = usuario
        self.contra = contra
        self.nombre = nombre

    }
}

