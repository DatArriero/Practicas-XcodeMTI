//
//  ViewController2.swift
//  proyecto_final
//
//  Created by Villanueva on 03/12/18.
//  Copyright © 2018 All rights reserved.
//

import UIKit

class ViewController2: UIViewController {

    @IBOutlet weak var usuario: UITextField!
    
    
    @IBOutlet weak var contraseña: UITextField!
    @IBOutlet weak var nombre: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        let tap = UITapGestureRecognizer(target: self,action: #selector(hideKeyboard))
        view.addGestureRecognizer(tap)
        // Do any additional setup after loading the view, typically from a nib.
    }
    @objc func hideKeyboard()
    {
        view.endEditing(true)
    }
    

    @IBAction func completar_registro(_ sender: Any) {
        
        if(usuario.text?.isEmpty)!{
            let alert=UIAlertController(title: "Error", message: "Por favor ingrese usuario", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alert, animated: true, completion: nil)
        }
        else if(contraseña.text?.isEmpty)!{
            let alert=UIAlertController(title: "Error", message: "Por favor ingrese contraseña", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alert, animated: true, completion: nil)
        }
        else if(nombre.text?.isEmpty)!{
            let alerta=UIAlertController(title: "Error", message: "Por favor ingrese nombre", preferredStyle: UIAlertController.Style.alert)
            alerta.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alerta, animated: true, completion: nil)
        }
        else{
            
             users.append(Users(usuario:usuario.text!, contra:contraseña.text! , nombre:nombre.text!))
            let alert=UIAlertController(title: "Se ha completado el registro", message: "El usuario ha sido registrado", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alert, animated: true, completion: nil)
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

