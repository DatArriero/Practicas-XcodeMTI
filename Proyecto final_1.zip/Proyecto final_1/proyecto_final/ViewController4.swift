//
//  ViewController4.swift
//  proyecto_final
//
//  Created by Villanueva on 03/12/18.
//  Copyright © 2018 All rights reserved.
//

import UIKit

class ViewController4: UIViewController {

    @IBOutlet weak var txtDuracion: UITextField!
    @IBOutlet weak var txtPelicula: UITextField!
    @IBOutlet weak var imgFoto: UIImageView!
    @IBOutlet weak var txtPrecio: UITextField!
    
    var img: UIImage!
    var imagePick = UIImagePickerController()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        let tap = UITapGestureRecognizer(target: self,action: #selector(hideKeyboard))
        view.addGestureRecognizer(tap)
        // Do any additional setup after loading the view, typically from a nib.
    }
    @objc func hideKeyboard()
    {
        view.endEditing(true)
    }
    
    @IBAction func agregar_imagen(_ sender: Any) {
        imagePick.sourceType = .photoLibrary
        imagePick.allowsEditing = true
        imagePick.delegate = self
        present(imagePick, animated: true, completion: nil)
    }
    @IBAction func agregar_comida(_ sender: Any) {
        if(txtPelicula.text?.isEmpty)!{
            let alert=UIAlertController(title: "Error", message: "Ingrese nombre", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alert, animated: true, completion: nil)
        }
        else if(txtPrecio.text?.isEmpty)!{
            let alert=UIAlertController(title: "Error", message: "Ingrese precio", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alert, animated: true, completion: nil)
        }
        else if(txtDuracion.text?.isEmpty)!{
            let alert=UIAlertController(title: "Error", message: "Ingrese porcion", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alert, animated: true, completion: nil)
        }
        else{
            Peliculas.append(txtPelicula.text!)
            Precios.append(txtPrecio.text!)
            Duracion.append(txtDuracion.text!)
            imag.append(self.img)
            let alert=UIAlertController(title: "Exito", message: "Comida registrada", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alert, animated: true, completion: nil)
        }
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
extension ViewController4: UIImagePickerControllerDelegate, UINavigationControllerDelegate{
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let imagee = info[.originalImage] as? UIImage {
            imgFoto.image = imagee
            img = imagee
        }
        dismiss(animated: true, completion: nil)
    }
}
